import React, { useEffect, useRef, useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Calculator, Save, ArrowLeft, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

import ScheduleSelector from "@/components/ScheduleSelector";
import { calcInfusionRate, calcTotals } from "@/lib/nutrition";
import { useParams } from "react-router-dom";
import { supabase } from "@/lib/supabase"; // ajuste ao seu path

/* ===========================
   Tipagens
   =========================== */

interface FormulaEntry {
  id: string;
  formulaId: string;
  volume: string; // string for controlled input
  hours: string[];
}

type ModuleType =
  | "moduliprotein"
  | "modulipulver"
  | "resource_protein"
  | "benfiber"
  | "maltodextrina"
  | "tcm"
  | "glutamin"
  | "proteina_isolada"
  | "cal_300"
  | "cal_400";

interface ModuleEntry {
  id: string;
  type: ModuleType | "";
  amount: string; // numeric as string
}

interface PrescriptionState {
  route: "" | "oral" | "enteral" | "parenteral";
  clinic: string;
  infusionMode: string;
  system: "" | "aberto" | "fechado";
  infusionTime: string;
  dilute: boolean;
  diluteVolume: string;
  intercalar: "nao" | "sim";
  notes: string;
  enteralAccess: string;
  waterVolume: string; // hidratação enteral (mL/dia)
  // ORAL specific
  oralType?: string; // e.g. 'vo' | 'vo+ne'
  oralConsistency?: string;
  oralSupplement?: string;
  oralVolumeDay?: string;
  // PARENTERAL specific
  parenteralType?: string; // 'tnpa' | 'tnpt'
  parenteralCatheter?: string; // 'periferico' | 'central'
  parenteralOsmolarity?: string;
  parenteralVolume?: string;
  parenteralHydration?: string; // hidratação venosa
  // dynamic lists
  formulas: FormulaEntry[];
  modules: ModuleEntry[]; // only for enteral
}

/* ===========================
   Dados estáticos: fórmulas e módulos (lista B)
   =========================== */

const ALL_FORMULAS = [
  { id: "1", name: "Nutrison Advanced Diason", calories: 1.0, protein: 4.0, type: "fechado" },
  { id: "2", name: "Fresubin Original", calories: 1.0, protein: 3.8, type: "fechado" },
  { id: "3", name: "Peptamen", calories: 1.0, protein: 4.0, type: "fechado" },
  { id: "4", name: "Nutridrink", calories: 1.5, protein: 6.0, type: "fechado" },
  { id: "5", name: "Fórmula Artesanal", calories: 1.0, protein: 3.5, type: "aberto" },
  { id: "6", name: "Caseira Exemplo", calories: 0.9, protein: 3.0, type: "aberto" },
];

/**
 * Lista B — módulos (labels e unidades)
 * Unidade apenas para apresentação; cálculo simplificado implementado posteriormente.
 */
const MODULE_OPTIONS: { value: ModuleType; label: string; unit: "g" | "kcal" }[] = [
  { value: "moduliprotein", label: "Moduliprotein", unit: "g" },
  { value: "modulipulver", label: "Modulipulver", unit: "g" },
  { value: "resource_protein", label: "Resource Protein", unit: "g" },
  { value: "benfiber", label: "Benfiber", unit: "g" },
  { value: "maltodextrina", label: "Maltodextrina", unit: "g" },
  { value: "tcm", label: "TCM", unit: "g" },
  { value: "glutamin", label: "Glutamin", unit: "g" },
  { value: "proteina_isolada", label: "Proteína isolada (pó)", unit: "g" },
  { value: "cal_300", label: "Calórico 300 kcal", unit: "kcal" },
  { value: "cal_400", label: "Calórico 400 kcal", unit: "kcal" },
];

/* ===========================
   Componente principal
   =========================== */

const Prescription: React.FC = () => {
  const navigate = useNavigate();

  const patient = JSON.parse(localStorage.getItem("patient") || "{}");

  const [prescription, setPrescription] = useState<PrescriptionState>({
    route: "",
    clinic: "",
    infusionMode: "",
    system: "",
    infusionTime: "",
    dilute: false,
    diluteVolume: "",
    intercalar: "nao",
    notes: "",
    enteralAccess: "",
    waterVolume: "",
    oralType: "",
    oralConsistency: "",
    oralSupplement: "",
    oralVolumeDay: "",
    parenteralType: "",
    parenteralCatheter: "",
    parenteralOsmolarity: "",
    parenteralVolume: "",
    parenteralHydration: "",
    formulas: [{ id: Date.now().toString(), formulaId: "", volume: "", hours: [] }],
    modules: [],
  });

  // menu sistema open/close
  const [systemMenuOpen, setSystemMenuOpen] = useState(false);
  const systemTriggerRef = useRef<HTMLDivElement | null>(null);

  // cálculos mostrados no rodapé
  const [calculations, setCalculations] = useState({
    totalCalories: 0,
    totalProtein: 0,
    infusionRate: 0,
    totalVolume: 0,
  });

  // fórmulas compatíveis com system
  const availableFormulas = prescription.system
    ? ALL_FORMULAS.filter((f) => f.type === prescription.system)
    : [];

  // helper setField com tipagem
  const setField = <K extends keyof PrescriptionState>(field: K, value: PrescriptionState[K]) => {
    setPrescription((p) => ({ ...p, [field]: value }));
  };

  // fórmulas: add/remove/update
  const addFormulaEntry = () => {
    setPrescription((p) => ({
      ...p,
      formulas: [...p.formulas, { id: Date.now().toString(), formulaId: "", volume: "", hours: [] }],
    }));
  };

  const removeFormulaEntry = (id: string) => {
    setPrescription((p) => ({ ...p, formulas: p.formulas.filter((f) => f.id !== id) }));
  };

  const updateFormulaEntry = (id: string, patch: Partial<FormulaEntry>) => {
    setPrescription((p) => ({ ...p, formulas: p.formulas.map((f) => (f.id === id ? { ...f, ...patch } : f)) }));
  };

  // módulos: add/remove/update
  const addModule = () => {
    setPrescription((p) => ({ ...p, modules: [...p.modules, { id: Date.now().toString(), type: "", amount: "" }] }));
  };

  const removeModule = (id: string) => {
    setPrescription((p) => ({ ...p, modules: p.modules.filter((m) => m.id !== id) }));
  };

  const updateModule = (id: string, patch: Partial<ModuleEntry>) => {
    setPrescription((p) => ({ ...p, modules: p.modules.map((m) => (m.id === id ? { ...m, ...patch } : m)) }));
  };

  // quando trocar system, limpar formuleIds incompatíveis
  useEffect(() => {
    if (!prescription.system) {
      setPrescription((p) => ({ ...p, formulas: p.formulas.map((f) => ({ ...f, formulaId: "" })) }));
      return;
    }
    setPrescription((p) => ({
      ...p,
      formulas: p.formulas.map((f) =>
        f.formulaId && !availableFormulas.some((af) => af.id === f.formulaId) ? { ...f, formulaId: "" } : f
      ),
    }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prescription.system]);

  /* -------------------------
     Cálculos totais (ENTERAL)
     - usa fórmulas + módulos + água (hidratação enteral)
     ------------------------- */
  useEffect(() => {
    // Se route !== enteral, as somas de enteral não são relevantes; mas deixamos cálculo flexível
    if (prescription.route !== "enteral") {
      setCalculations((c) => ({ ...c, totalCalories: 0, totalProtein: 0, totalVolume: 0, infusionRate: 0 }));
      return;
    }

    let totalCalories = 0;
    let totalProtein = 0;
    let totalVolume = 0;

    // fórmulas
    for (const f of prescription.formulas) {
      const vol = Number(f.volume || 0);
      totalVolume += vol;
      if (f.formulaId) {
        const fo = ALL_FORMULAS.find((a) => a.id === f.formulaId);
        if (fo) {
          try {
            const t = calcTotals(fo, vol);
            if (t && typeof t.totalCalories !== "undefined") {
              totalCalories += Number(t.totalCalories || 0);
            } else {
              // suposição: fo.calories é kcal/mL
              totalCalories += (fo.calories || 0) * vol;
            }
            if (t && typeof t.totalProtein !== "undefined") {
              totalProtein += Number(t.totalProtein || 0);
            } else {
              // fallback: fo.protein is g/100mL? original code used /100
              // para manter compatibilidade, assumimos fo.protein é g/100mL
              totalProtein += ((fo.protein || 0) * vol) / 100;
            }
          } catch {
            totalCalories += (fo.calories || 0) * vol;
            totalProtein += ((fo.protein || 0) * vol) / 100;
          }
        }
      }
    }

    // hidratação enteral (água flush) — soma no volume total, não altera macros
    const waterVol = Number(prescription.waterVolume || 0);
    totalVolume += waterVol;

    // módulos (SIMPLES)
    // regras simples (conforme opção A):
    // - proteicos (moduliprotein/modulipulver/resource_protein/proteina_isolada): soma em g proteína 1:1
    // - benfiber: fibra (não entra no cálculo kcal/protein)
    // - maltodextrina: 4 kcal/g
    // - tcm: 8.3 kcal/g
    // - glutamin: 4 kcal/g
    // - cal_300 / cal_400: soma direta em kcal
    for (const m of prescription.modules) {
      const amt = Number(m.amount || 0);
      if (!m.type || !amt) continue;
      switch (m.type) {
        case "moduliprotein":
        case "modulipulver":
        case "resource_protein":
        case "proteina_isolada":
          totalProtein += amt; // 1g proteína por 1g suplemento (simples)
          break;
        case "benfiber":
          // fibra — não soma kcal nem proteína
          break;
        case "maltodextrina":
          totalCalories += 4 * amt;
          break;
        case "tcm":
          // TCM simplificado: 8.3 kcal/g
          totalCalories += 8.3 * amt;
          break;
        case "glutamin":
          totalCalories += 4 * amt;
          break;
        case "cal_300":
          totalCalories += 300;
          break;
        case "cal_400":
          totalCalories += 400;
          break;
        default:
          break;
      }
    }

    // calcular velocidade: usa totalVolume e infusionTime (horas)
    const infusionRate = calcInfusionRate(totalVolume, Number(prescription.infusionTime || 0), prescription.system);

    setCalculations({
      totalCalories: Math.round(totalCalories * 100) / 100,
      totalProtein: Math.round(totalProtein * 100) / 100,
      infusionRate,
      totalVolume,
    });
  }, [prescription.formulas, prescription.modules, prescription.waterVolume, prescription.infusionTime, prescription.system, prescription.route]);

  /* -------------------------
     Conflito de horários (alerta não bloqueante)
     ------------------------- */
  useEffect(() => {
    // só faz sentido para enteral (vários horários por fórmula)
    if (prescription.route !== "enteral") return;

    const hourMap: Record<string, number> = {};
    for (const f of prescription.formulas) {
      for (const h of f.hours || []) {
        hourMap[h] = (hourMap[h] || 0) + 1;
      }
    }
    const conflicts = Object.entries(hourMap).filter(([, v]) => v > 1).map(([k]) => k);
    if (conflicts.length > 0) {
      toast.warning(`Atenção: fórmulas com mesmo horário: ${conflicts.join(", ")}`);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prescription.formulas.map((f) => (f.hours || []).join(",")).join("|"), prescription.route]);

  /* -------------------------
     Handlers salvar / fechar
     ------------------------- */
  const handleSave = () => {
    // aqui você pode validar e enviar ao backend
    toast.success("Prescrição salva!");
    navigate("/dashboard");
  };

  const handleClose = () => {
    navigate(-1);
  };

  /* ===========================
     Render
     =========================== */
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center py-10 px-4 bg-black/30">
      <div className="w-full max-w-6xl h-[90vh] overflow-auto bg-background rounded-lg shadow-lg p-6">
        {/* header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={handleClose}>
              <ArrowLeft />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Nova Prescrição Nutricional</h1>
              <p className="text-sm text-muted-foreground">Preencha os dados da prescrição</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="ghost" onClick={() => window.print()}>
              Imprimir
            </Button>
            <Button onClick={handleSave}>
              <Save className="mr-2" /> Salvar
            </Button>
          </div>
        </div>

        {/* grid principal */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Dados do paciente (esquerda) */}
          <Card>
            <CardHeader>
              <CardTitle>Dados do Paciente</CardTitle>
              <CardDescription>Campos extraídos do localStorage</CardDescription>
            </CardHeader>

            <CardContent className="space-y-3">
              <div>
                <Label>Nome</Label>
                <p className="font-medium">{patient.name || "—"}</p>
              </div>

              <div>
                <Label>Prontuário</Label>
                <p className="font-medium">{patient.record || "—"}</p>
              </div>

              <Separator />

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Peso (kg)</Label>
                  <p className="font-medium">{patient.weight ?? "—"}</p>
                </div>
                <div>
                  <Label>Altura (cm)</Label>
                  <p className="font-medium">{patient.height ?? "—"}</p>
                </div>
              </div>

              <div>
                <Label>IMC</Label>
                <p className="font-semibold">
                  {patient.weight && patient.height ? (patient.weight / Math.pow(patient.height / 100, 2)).toFixed(1) : "—"}
                </p>
              </div>

              <Separator />

              <div>
                <Label>Idade</Label>
                <p className="font-medium">{patient.age ?? "—"}</p>
              </div>

              <div>
                <Label>Sexo</Label>
                <p className="font-medium">{patient.sex || "—"}</p>
              </div>

              <Separator />

              <div>
                <Label>Clínica / Unidade</Label>
                <Select value={prescription.clinic ?? ""} onValueChange={(v) => setField("clinic", v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a clínica" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="clinica_a">Clínica A</SelectItem>
                    <SelectItem value="clinica_b">Clínica B</SelectItem>
                    <SelectItem value="clinica_c">Clínica C</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Diagnóstico</Label>
                <p className="font-medium">{patient.diagnosis || "—"}</p>
              </div>

              <div>
                <Label>Alergias</Label>
                <p className="font-medium">{patient.allergies || "—"}</p>
              </div>
            </CardContent>
          </Card>

          {/* Prescrição (direita) */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Dados da Prescrição</CardTitle>
              <CardDescription>Defina via, sistema, fórmulas, módulos e horários</CardDescription>
            </CardHeader>

            <CardContent className="space-y-4">
              {/* Via */}
              <div>
                <Label>Via de alimentação</Label>
                <div className="flex gap-4 mt-2">
                  {(["oral", "enteral", "parenteral"] as const).map((r) => (
                    <label key={r} className="flex items-center gap-2 capitalize">
                      <input type="radio" name="route" checked={prescription.route === r} onChange={() => setField("route", r)} />
                      {r}
                    </label>
                  ))}
                </div>
              </div>

              <Separator />

              {/* ORAL — layout reduzido */}
              {prescription.route === "oral" && (
                <div>
                  <Card>
                    <CardHeader>
                      <CardTitle>Terapia Oral</CardTitle>
                      <CardDescription>Campos de prescrição via oral</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <div>
                          <Label>Tipo</Label>
                          <Select value={prescription.oralType ?? ""} onValueChange={(v) => setField("oralType", v)}>
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione tipo" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="vo">VO</SelectItem>
                              <SelectItem value="vo_ne">VO + NE</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label>Consistência</Label>
                          <Select value={prescription.oralConsistency ?? ""} onValueChange={(v) => setField("oralConsistency", v)}>
                            <SelectTrigger>
                              <SelectValue placeholder="Consistência" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="liquida">Líquida</SelectItem>
                              <SelectItem value="pastosa">Pastosa</SelectItem>
                              <SelectItem value="normal">Normal</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label>Suplemento oral</Label>
                          <Input value={prescription.oralSupplement ?? ""} onChange={(e) => setField("oralSupplement", e.target.value)} />
                        </div>
                      </div>

                      <div>
                        <Label>Volume/dia (mL)</Label>
                        <Input type="number" value={prescription.oralVolumeDay ?? ""} onChange={(e) => setField("oralVolumeDay", e.target.value)} />
                      </div>

                      <div>
                        <Label>Observações</Label>
                        <Textarea rows={3} value={prescription.notes ?? ""} onChange={(e) => setField("notes", e.target.value)} />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* ENTERAL — layout completo (fiel ao PDF) */}
              {prescription.route === "enteral" && (
                <div>
                  <Card>
                    <CardHeader>
                      <CardTitle>Terapia Nutricional Enteral</CardTitle>
                      <CardDescription>Preencha sistema, acesso, fórmulas, módulos e hidratação</CardDescription>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        {/* modo de infusão */}
                        <div>
                          <Label>Modo de infusão</Label>
                          <Select value={prescription.infusionMode ?? ""} onValueChange={(v) => setField("infusionMode", v)}>
                            <SelectTrigger>
                              <SelectValue placeholder="Modo de infusão" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="bomba">Bomba de Infusão</SelectItem>
                              <SelectItem value="grav">Gravitacional</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {/* sistema: botão que abre menu e fecha ao selecionar */}
                        <div className="relative">
                          <Label>Sistema</Label>
                          <div ref={systemTriggerRef} className="inline-block w-full">
                            <button onClick={() => setSystemMenuOpen((s) => !s)} className="w-full border rounded px-3 py-2 text-left mt-2">
                              <div className="flex justify-between items-center">
                                <span>{prescription.system ? (prescription.system === "aberto" ? "Sistema: Aberto" : "Sistema: Fechado") : "Sistema"}</span>
                                <span className="text-sm opacity-60">{systemMenuOpen ? "▲" : "▼"}</span>
                              </div>
                            </button>
                          </div>

                          {systemMenuOpen && (
                            <div className="absolute z-20 mt-2 w-full bg-white border rounded shadow">
                              <button className="w-full text-left px-3 py-2 hover:bg-gray-50" onClick={() => { setField("system", "aberto"); setSystemMenuOpen(false); }}>
                                Sistema Aberto
                              </button>
                              <button className="w-full text-left px-3 py-2 hover:bg-gray-50" onClick={() => { setField("system", "fechado"); setSystemMenuOpen(false); }}>
                                Sistema Fechado
                              </button>
                            </div>
                          )}
                        </div>

                        {/* tempo de infusão (geral) */}
                        <div>
                          <Label>Tempo de infusão (horas)</Label>
                          <Input type="number" value={prescription.infusionTime ?? ""} onChange={(e) => setField("infusionTime", e.target.value)} />
                        </div>
                      </div>

                      {/* acesso enteral */}
                      <div>
                        <Label>Acesso Enteral</Label>
                        <Select value={prescription.enteralAccess ?? ""} onValueChange={(v) => setField("enteralAccess", v)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o acesso enteral" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="SOE">Sonda Oroenteral (SOE)</SelectItem>
                            <SelectItem value="SNE">Sonda Nasoenteral (SNE)</SelectItem>
                            <SelectItem value="SNG">Sonda Nasogástrica (SNG)</SelectItem>
                            <SelectItem value="GTT">Gastrostomia (GTT/PEG)</SelectItem>
                            <SelectItem value="JTT">Jejunostomia (JTT)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <Separator />

                      {/* Fórmulas dinâmicas */}
                      <div>
                        <Label>Fórmulas</Label>
                        <p className="text-sm text-muted-foreground mb-2">Escolha o sistema primeiro para liberar fórmulas compatíveis.</p>

                        <div className="space-y-3">
                          {prescription.formulas.map((entry, idx) => {
                            const selectedFormula = ALL_FORMULAS.find((f) => f.id === entry.formulaId);
                            return (
                              <Card key={entry.id} className="p-3">
                                <div className="flex flex-col md:flex-row md:items-start md:gap-4">
                                  <div className="flex-1 space-y-2">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                      <div>
                                        <Label>Fórmula {idx + 1}</Label>
                                        <Select value={entry.formulaId ?? ""} onValueChange={(v) => updateFormulaEntry(entry.id, { formulaId: v })} disabled={!prescription.system}>
                                          <SelectTrigger>
                                            <SelectValue placeholder={prescription.system ? "Selecione a fórmula" : "Escolha o sistema primeiro"} />
                                          </SelectTrigger>
                                          <SelectContent>
                                            {availableFormulas.map((af) => (
                                              <SelectItem key={af.id} value={af.id}>
                                                <div className="flex justify-between w-full">
                                                  {af.name}
                                                  <Badge>{af.type}</Badge>
                                                </div>
                                              </SelectItem>
                                            ))}
                                          </SelectContent>
                                        </Select>
                                      </div>

                                      <div>
                                        <Label>Volume (mL)</Label>
                                        <Input type="number" value={entry.volume ?? ""} onChange={(e) => updateFormulaEntry(entry.id, { volume: e.target.value })} />
                                      </div>
                                    </div>

                                    <div>
                                      <Label>Horários (para esta fórmula)</Label>
                                      <ScheduleSelector value={entry.hours || []} onChange={(v) => updateFormulaEntry(entry.id, { hours: v })} />
                                    </div>
                                  </div>

                                  <div className="flex-shrink-0 mt-3 md:mt-0 flex flex-col items-end gap-3">
                                    <div className="text-right">
                                      <p className="text-sm text-muted-foreground">Subtotal</p>
                                      <p className="font-semibold">
                                        {selectedFormula && entry.volume ? (() => {
                                          try {
                                            const t = calcTotals(selectedFormula, Number(entry.volume || 0));
                                            if (t && typeof t.totalCalories !== "undefined") return `${t.totalCalories} kcal • ${t.totalProtein} g`;
                                            return "—";
                                          } catch {
                                            return "—";
                                          }
                                        })() : "—"}
                                      </p>
                                    </div>

                                    <div className="flex gap-2">
                                      {prescription.formulas.length > 1 && <Button variant="destructive" onClick={() => removeFormulaEntry(entry.id)}>Remover</Button>}
                                    </div>
                                  </div>
                                </div>
                              </Card>
                            );
                          })}
                        </div>

                        <div className="flex gap-2 mt-3">
                          <Button onClick={addFormulaEntry}>+ Adicionar fórmula</Button>
                        </div>
                      </div>

                      <Separator />

                      {/* Módulos (lista B) */}
                      <div>
                        <Label>Módulos (opcional)</Label>
                        <p className="text-sm text-muted-foreground mb-2">Adicione suplementos/modulos (p.ex. proteína, maltodextrina, TCM, calóricos).</p>

                        <div className="space-y-3">
                          {prescription.modules.map((m) => {
                            const opt = MODULE_OPTIONS.find((o) => o.value === m.type);
                            return (
                              <div key={m.id} className="flex gap-2 items-center">
                                <div className="w-64">
                                  <Select value={m.type ?? ""} onValueChange={(v) => updateModule(m.id, { type: v as ModuleType })}>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Selecione módulo" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {MODULE_OPTIONS.map((mo) => (
                                        <SelectItem key={mo.value} value={mo.value}>
                                          {mo.label}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </div>

                                <div className="w-36">
                                  <Input type="number" value={m.amount ?? ""} onChange={(e) => updateModule(m.id, { amount: e.target.value })} placeholder={opt ? (opt.unit === "g" ? "g" : "kcal") : ""} />
                                </div>

                                <div className="flex gap-2">
                                  <Button variant="destructive" onClick={() => removeModule(m.id)}>Remover</Button>
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        <div className="flex gap-2 mt-3">
                          <Button onClick={addModule}>+ Adicionar módulo</Button>
                        </div>
                      </div>

                      <Separator />

                      {/* Hidratação / água de flush */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 items-end">
                        <div>
                          <Label>Água / Hidratação (mL/dia)</Label>
                          <Input type="number" value={prescription.waterVolume ?? ""} onChange={(e) => setField("waterVolume", e.target.value)} />
                        </div>

                        <div className="flex items-center gap-3">
                          <input type="checkbox" checked={!!prescription.dilute} onChange={(e) => setField("dilute", e.target.checked)} />
                          <span>Diluir até</span>
                          <Input type="number" className="w-28" disabled={!prescription.dilute} value={prescription.diluteVolume ?? ""} onChange={(e) => setField("diluteVolume", e.target.value)} />
                          <span>ml</span>
                        </div>
                      </div>

                      <div>
                        <Label>Intercalar fórmulas?</Label>
                        <div className="flex gap-6 mt-2">
                          <label className="flex items-center gap-2">
                            <input type="radio" name="intercalar" checked={prescription.intercalar === "sim"} onChange={() => setField("intercalar", "sim")} />
                            Sim
                          </label>

                          <label className="flex items-center gap-2">
                            <input type="radio" name="intercalar" checked={prescription.intercalar === "nao"} onChange={() => setField("intercalar", "nao")} />
                            Não
                          </label>
                        </div>
                      </div>

                      <div>
                        <Label>Observações</Label>
                        <Textarea rows={3} value={prescription.notes ?? ""} onChange={(e) => setField("notes", e.target.value)} />
                      </div>

                      <div className="flex gap-2">
                        <Button onClick={handleSave} className="w-full"><Save className="mr-2" /> Salvar Prescrição</Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* PARENTERAL — layout específico (conforme PDF) */}
              {prescription.route === "parenteral" && (
                <div>
                  <Card>
                    <CardHeader>
                      <CardTitle>Nutrição Parenteral</CardTitle>
                      <CardDescription>Preencha parâmetros específicos da TN parenteral</CardDescription>
                    </CardHeader>

                    <CardContent className="space-y-3">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <div>
                          <Label>Tipo TN</Label>
                          <Select value={prescription.parenteralType ?? ""} onValueChange={(v) => setField("parenteralType", v)}>
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione tipo" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="tnpa">TNPA</SelectItem>
                              <SelectItem value="tnpt">TNPT</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label>Tipo de Cateter</Label>
                          <Select value={prescription.parenteralCatheter ?? ""} onValueChange={(v) => setField("parenteralCatheter", v)}>
                            <SelectTrigger>
                              <SelectValue placeholder="Tipo cateter" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="periferico">Periférico</SelectItem>
                              <SelectItem value="central">Central</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label>Osmolaridade (mOsm/L)</Label>
                          <Input type="number" value={prescription.parenteralOsmolarity ?? ""} onChange={(e) => setField("parenteralOsmolarity", e.target.value)} />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <div>
                          <Label>Volume TN (mL)</Label>
                          <Input type="number" value={prescription.parenteralVolume ?? ""} onChange={(e) => setField("parenteralVolume", e.target.value)} />
                        </div>

                        <div>
                          <Label>Hidratação venosa (mL)</Label>
                          <Input type="number" value={prescription.parenteralHydration ?? ""} onChange={(e) => setField("parenteralHydration", e.target.value)} />
                        </div>

                        <div>
                          <Label>Tempo de infusão (horas)</Label>
                          <Input type="number" value={prescription.infusionTime ?? ""} onChange={(e) => setField("infusionTime", e.target.value)} />
                        </div>
                      </div>

                      <div>
                        <Label>Observações</Label>
                        <Textarea rows={3} value={prescription.notes ?? ""} onChange={(e) => setField("notes", e.target.value)} />
                      </div>

                      <div className="flex gap-2">
                        <Button onClick={handleSave} className="w-full"><Save className="mr-2" /> Salvar Prescrição</Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Rodapé: cálculos */}
        <div className="mt-6">
          <Card className="border-primary">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Calculator /> Cálculos Nutricionais</CardTitle>
            </CardHeader>

            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div>
                  <p className="text-muted-foreground text-sm">Volume total</p>
                  <p className="text-xl font-bold">{calculations.totalVolume} mL</p>
                </div>

                <div>
                  <p className="text-muted-foreground text-sm">Calorias totais</p>
                  <p className="text-xl font-bold">{calculations.totalCalories} kcal</p>
                </div>

                <div>
                  <p className="text-muted-foreground text-sm">Proteína total</p>
                  <p className="text-xl font-bold">{calculations.totalProtein} g</p>
                </div>

                <div>
                  <p className="text-muted-foreground text-sm">Velocidade da infusão</p>
                  {/* Para parenteral: calcular velocidade distinta (TN volume + hidratação) */}
                  <p className="text-xl font-bold">
                    {prescription.route === "parenteral"
                      ? (() => {
                          const vol = Number(prescription.parenteralVolume || 0) + Number(prescription.parenteralHydration || 0);
                          const rate = calcInfusionRate(vol, Number(prescription.infusionTime || 0), "fechado");
                          return `${rate} ml/h`;
                        })()
                      : `${calculations.infusionRate} ${prescription.system === "fechado" ? "ml/h" : "gotas/min"}`}
                  </p>
                </div>
              </div>

              <div className="mt-4 flex gap-3 p-4 bg-muted rounded-lg">
                <AlertCircle />
                <div className="space-y-1 text-sm">
                  <p>Recomendações gerais:</p>
                  <ul className="list-disc list-inside">
                    <li>25–30 kcal/kg/dia</li>
                    <li>1.0–1.5 g proteína/kg/dia</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Prescription;
